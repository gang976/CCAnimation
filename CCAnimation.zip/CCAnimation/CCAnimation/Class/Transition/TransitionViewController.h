//
//  TransitionViewController.h
//  CCAnimation
//
//  Created by ZhangCc on 2018/5/30.
//  Copyright © 2018年 ZhangCc. All rights reserved.
//

//过渡动画

#import "BaseViewController.h"

@interface TransitionViewController : BaseViewController

- (instancetype)initWithType:(TransitionType)type;

@end

//
//  GroupViewController.h
//  CCAnimation
//
//  Created by ZhangCc on 2018/5/30.
//  Copyright © 2018年 ZhangCc. All rights reserved.
//

//组动画

#import "BaseViewController.h"

@interface GroupViewController : BaseViewController

- (instancetype)initWithType:(GroupType)type;

@end

//
//  BasicViewController.h
//  CCAnimation
//
//  Created by ZhangCc on 2018/5/30.
//  Copyright © 2018年 ZhangCc. All rights reserved.
//

//基础动画

#import "BaseViewController.h"

@interface BasicViewController : BaseViewController

- (instancetype)initWithType:(BasicType)type;

@end
